﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Covid19App.Models;

namespace Covid19App.Controllers
{
    [Area("User")]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AdminManagement()
        {
            return View();
        }

        public IActionResult StaffManagement()
        {
            return View();
        }
        public IActionResult Edit(string button, string id)
        {
            switch (button)
            {
                case "Maui":
                    return View("Maui");
                case "Sunni":
                    return View("Sunni");
                case "Hao":
                    return View("Hao");
                case "Lyle":
                    return View("Lyle");
                case "Shivani":
                    return View("Shivani");
                case "Jaxson":
                    return View("Jaxson");
                case "Mohamed":
                    return View("Mohamed");
                default:
                    return View("AdminManagement");
            }
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
