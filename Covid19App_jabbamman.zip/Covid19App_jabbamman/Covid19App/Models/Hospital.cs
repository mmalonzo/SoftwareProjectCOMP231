﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Covid19App.Models
{
    public class Hospital
    {
        public string HospitalName { get; set; }
        public double Distance { get; set; }
        public string AvailableDate { get; set; }
        public string AvailableTime { get; set; }

    }
}
